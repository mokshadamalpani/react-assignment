import { useState } from "react";
import "./App.css";
import ProfileCart from "./components/ProfileCart";
import list from "./profile.json";

function App() {
  const [data, setData] = useState(list);

  const getData = (id) => {
    const updatedList = list.filter((item) => {
      return item.id !== id;
    });
    setData(updatedList);
  };
  return (
    <div className="container">
      {data.map((item) => {
           return <ProfileCart {...item} changeDeleteHandler={getData} key={item.id}/>;
      })}
    </div>
  );
}

export default App;
